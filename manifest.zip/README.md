# calm-media-downloader
This is an extensions (working in firefox or chrome) that allows easier downloads of owned media from thecalm.site
